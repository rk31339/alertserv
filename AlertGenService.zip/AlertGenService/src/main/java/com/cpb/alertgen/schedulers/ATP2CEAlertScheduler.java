package com.cpb.alertgen.schedulers;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.cpb.alertgen.model.AlertDetails;

/*
 * Author:Rafiq Khan
 */

@Component
public class ATP2CEAlertScheduler {
	private static final DateTimeFormatter datefrmt = DateTimeFormatter.ofPattern("dd-MMM-yy hh:mm:ss");

	@Scheduled(initialDelay = 1000, fixedRate = 10000)
	public void CheckAppiaFailures() {
		LocalDateTime today = LocalDateTime.now();
		System.out.format("Scheuler 1-Checking for Appia Failures at %s\n", today.format(datefrmt));

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		
		try {
			List<AlertDetails> alertDet = mapper.readValue(new URL("file:src/main/resources/config/alert_cfg.json"),
					new TypeReference<List<AlertDetails>>() {
					});
			
			System.out.println(alertDet.size());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
