package com.cpb.alertgen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
/*
 * Author:Rafiq Khan
 */

@SpringBootApplication
@EnableScheduling
public class AlertGenApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlertGenApplication.class, args);
	}

}
