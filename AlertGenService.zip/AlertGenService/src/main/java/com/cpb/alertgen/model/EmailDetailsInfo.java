package com.cpb.alertgen.model;

import java.io.File;
import java.util.Arrays;
import java.util.Map;
/*
 * Author:Rafiq Khan
 * Desc: Object Holding Email Details
 */

public class EmailDetailsInfo {
	
	private String mailFrom;
	private String[] mailTo;
	private String[] mailCc;
	private String[] mailBcc;
	private String mailSubject;	
	private String emailTmpltName;
	private Map < String, Object > emailTmpltDataMap;
	private String mailPriority;	
	private String attachmntNames[];
	
	public String getMailFrom() {
		return mailFrom;
	}
	public void setMailFrom(String mailFrom) {
		this.mailFrom = mailFrom;
	}
	public String[] getMailTo() {
		return mailTo;
	}
	public void setMailTo(String[] mailTo) {
		this.mailTo = mailTo;
	}
	public String[] getMailCc() {
		return mailCc;
	}
	public void setMailCc(String[] mailCc) {
		this.mailCc = mailCc;
	}
	public String[] getMailBcc() {
		return mailBcc;
	}
	public void setMailBcc(String[] mailBcc) {
		this.mailBcc = mailBcc;
	}
	public String getMailSubject() {
		return mailSubject;
	}
	public void setMailSubject(String mailSubject) {
		this.mailSubject = mailSubject;
	}
	public String getEmailTmpltName() {
		return emailTmpltName;
	}
	public void setEmailTmpltName(String emailTmpltName) {
		this.emailTmpltName = emailTmpltName;
	}
	public Map<String, Object> getEmailTmpltDataMap() {
		return emailTmpltDataMap;
	}
	public void setEmailTmpltDataMap(Map<String, Object> emailTmpltDataMap) {
		this.emailTmpltDataMap = emailTmpltDataMap;
	}
	public String getMailPriority() {
		return mailPriority;
	}
	public void setMailPriority(String mailPriority) {
		this.mailPriority = mailPriority;
	}
	public String[] getAttachmntNames() {
		return attachmntNames;
	}
	public void setAttachmntNames(String[] attachmntNames) {
		this.attachmntNames = attachmntNames;
	}
	
	@Override
	public String toString() {
		return "EmailDetailsInfo [mailFrom=" + mailFrom + ", mailTo=" + Arrays.toString(mailTo) + ", mailCc="
				+ Arrays.toString(mailCc) + ", mailBcc=" + Arrays.toString(mailBcc) + ", mailSubject=" + mailSubject
				+ ", emailTmpltName=" + emailTmpltName + ", emailTmpltDataMap=" + emailTmpltDataMap + ", mailPriority="
				+ mailPriority + ", attachmntNames=" + Arrays.toString(attachmntNames) + "]";
	}	
	
}
