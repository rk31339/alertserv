package com.cpb.alertgen.model;

import java.util.ArrayList;
/*
 * Author: Rafiq Khan
 */

public class EmailDetailsCfg {
	 
	 private String from;
	 ArrayList < Object > to = new ArrayList < Object > ();
	 ArrayList < Object > cc = new ArrayList < Object > ();
	 ArrayList < Object > bcc = new ArrayList < Object > ();
	 private String subject;
	 private String template;
	 private String priority;

	 // Getter Methods 

	 public String getFrom() {
	  return from;
	 }

	 public String getSubject() {
	  return subject;
	 }

	 public String getTemplate() {
	  return template;
	 }

	 public String getPriority() {
	  return priority;
	 }

	 // Setter Methods 

	 public void setFrom(String from) {
	  this.from = from;
	 }

	 public void setSubject(String subject) {
	  this.subject = subject;
	 }

	 public void setTemplate(String template) {
	  this.template = template;
	 }

	 public void setPriority(String priority) {
	  this.priority = priority;
	 }
	}