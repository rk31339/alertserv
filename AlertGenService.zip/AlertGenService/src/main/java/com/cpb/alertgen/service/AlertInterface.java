package com.cpb.alertgen.service;

public interface AlertInterface {
	void generateAlert();
}
