package com.cpb.alertgen.service;

import java.nio.charset.Charset;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.cpb.alertgen.model.EmailDetailsInfo;

/*
 * Author: Rafiq Khan
 */
public class EmailGenService {
	static final String URL_SEND_EMAIL = "http://localhost:8081/sendemail";
	public static final String USER_NAME = "rk31339";
    public static final String PASSWORD = "raPtoR";
    
    public void generateEmail(EmailDetailsInfo emailDetails) {		
		
		// Authentication
		String auth = USER_NAME + ":" + PASSWORD;
		byte[] encodedAuth = Base64.getEncoder().encode(auth.getBytes(Charset.forName("US-ASCII")));
		String authHeader = "Basic " + new String(encodedAuth);		

		HttpHeaders headers = new HttpHeaders();
		headers.add("Accept", MediaType.APPLICATION_JSON_VALUE);
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("Authorization", authHeader);
		HttpEntity<String> entity = new HttpEntity<String>(headers);
		
		RestTemplate restTemplate = new RestTemplate();

		// Data attached to the request.
		HttpEntity<EmailDetailsInfo> requestBody = new HttpEntity<>(emailDetails, headers);

		// Send request with POST method.
		// String e = restTemplate.postForObject(URL_SEND_EMAIL, requestBody,String.class);
		ResponseEntity<String> response = restTemplate.exchange(URL_SEND_EMAIL, HttpMethod.POST, requestBody, String.class);
		String e = response.getBody();

		if (e != null && e.contains("SUCCESS")) {
			System.out.println("Mail sent Successfully");
		} else {
			System.out.println("Failure in Sending Email");
		}
    	
    }
}
