package com.cpb.alertgen.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cpb.alertgen.model.EmailDetailsInfo;

@Service
public class ATP2CEAlertService implements AlertInterface {

	@Autowired
	EmailGenService emailGenService;

	@Override
	public void generateAlert() {
		System.out.println("Inside the method generate Alert");
		EmailDetailsInfo emailDetails =new EmailDetailsInfo();
		//set the email details
		emailGenService.generateEmail(emailDetails);
	}
}
