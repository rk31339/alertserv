package com.cpb.alertgen.model;

/*
 * Author: Rafiq Khan
 */
public class AlertDetails {
	
	private String AlertSQLKey;
	private String AlertDescription;
	EmailDetailsCfg EmailDetailsObject;

	// Getter Methods

	public String getAlertSQLKey() {
		return AlertSQLKey;
	}

	public String getAlertDescription() {
		return AlertDescription;
	}

	public EmailDetailsCfg getEmailDetails() {
		return EmailDetailsObject;
	}

	// Setter Methods

	public void setAlertSQLKey(String AlertSQLKey) {
		this.AlertSQLKey = AlertSQLKey;
	}

	public void setAlertDescription(String AlertDescription) {
		this.AlertDescription = AlertDescription;
	}

	public void setEmailDetails(EmailDetailsCfg EmailDetailsObject) {
		this.EmailDetailsObject = EmailDetailsObject;
	}
}